import { Const } from "./FPhi.Widget.const.wasm";

export namespace FPhi {
    export { Const as Selphi };
}