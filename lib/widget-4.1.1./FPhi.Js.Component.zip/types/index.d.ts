import { Const } from "./FPhi.Widget.const.wasm.js";

export namespace FPhi {
    export { Const as SelphID };
}
